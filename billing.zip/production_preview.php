<?php if (session_status() !== PHP_SESSION_ACTIVE) session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Jayam Hydraulic Engineering (Spares)</title>
    <link rel="icon" type="image/png" href="userdata/images/favicon.png">

    <!-- begin::global styles -->
    <link rel="stylesheet" href="vendors/bundle.css" type="text/css">
	<link rel="stylesheet" href="vendors/select2/css/select2.min.css" type="text/css">
    <!-- end::global styles -->

    <!-- begin::datepicker -->
    <link rel="stylesheet" href="vendors/datepicker/daterangepicker.css">
    <link rel="stylesheet" href="vendors/dataTable/responsive.bootstrap.min.css" type="text/css">
    <!-- begin::datepicker -->

    <!-- begin::vmap -->
    <link rel="stylesheet" href="vendors/vmap/jqvmap.min.css">
    <!-- begin::vmap -->

    <!-- begin::custom styles -->
    <link rel="stylesheet" href="css/app.min.css" type="text/css">
    <link rel="stylesheet" href="css/custom.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- end::custom styles -->
    

</head>
<body>
        <style>
		.no-wrap{
			word-break: break-all;
		}
		</style>
<?php include('sessionservices.php');?>
<!-- begin::page loader-->
<div class="page-loader">
    <div class="spinner-border"></div>
    <span>Loading ...</span>
</div>
<!-- end::page loader -->

<?php echo $header;?>

    <style>
        body {
            color: black;
        }

        #tablemainbind {
            vertical-align: bottom;
            padding: 0.2rem !important;
        }

        .table td {
            vertical-align: bottom !important;

        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            color: #444;
            line-height: 36px;
        }
        .watermark {
            position: absolute;
            opacity: 0.10;
            font-size: 3em;
            width: 30%;
            text-align: center;
            z-index: 1000;
            top: 60%;
            left: 35%;
            transform: translate(-50%, -50%);
        }

        @media print {
            footer {
                position: fixed;
                bottom: 0;
                /* text-align: center; */
                width: 100%;

            }
        }
.table-striped tbody tr:nth-of-type(odd){
	background-color: #fff;
}
    </style>
    <!-- begin::main content -->
    <main class="main-content" style="padding-top:0px">
        <?php
            $stock_id = $_GET['id'];
            $sql_supplier = "SELECT *,a.dc_no,date_format(a.billing_date,'%d/%m/%Y') as billing_date,d.supplier_id,d.supplier_name,d.company_name,d.gst_no,d.address FROM tbl_stock  a  
            left join  tbl_supplier d on d.supplier_id=a.supplier_id WHERE  a.delete_status!='0' and  d.delete_status!='0' and a.stock_id='$stock_id'";
            $query_supplier = mysqli_query($conn, $sql_supplier);
            $row_supplier = mysqli_fetch_array($query_supplier);

            $booking_type=$row_supplier['booking_type'];
            $billing_no=$row_supplier['dc_no'];
            $billing_date=$row_supplier['billing_date'];
            $supplier_name=$row_supplier['supplier_name'];
            $supplier_company=$row_supplier['company_name'];
            $supplier_address=$row_supplier['address'];
            $supplier_gst_no=$row_supplier['gst_no'];
            $cgst=$row_supplier['cgst'];
            $sgst=$row_supplier['sgst'];



            

        ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="text-right d-print-none" style="text-align: center!important;margin-top:0px">
                            <a href="javascript:window.print()" class="btn btn-success m-l-5 text-right" style="margin-top:0px;margin-right:15px;color: #fff"> <i class="fa fa-print m-r-5"></i> Print
                            </a>
                        </div>
                        <div class="watermark"><img src="images/sm_logo.jpeg" alt=""></div>
                        

                        <!--div class="row" style="margin-top: 50px;">
                            <div class="col-sm-12">
							<?php //if($row_supplier['billing_type']=='1'){ ?>
							<h3 style="text-align: center;padding: 5px;font-size: 20px;border: solid;border-color: #f0f0f0;margin-top: -20px;">PRO FORMA</h3>
							<?php //} else if($row_supplier['billing_type']=='2'){ ?>
							<h3 style="text-align: center;padding: 5px;font-size: 20px;border: solid;border-color: #f0f0f0;margin-top: -20px;">INVOICE</h3>
							<?php //} else if($row_supplier['billing_type']=='3'){ ?>
							<h3 style="text-align: center;padding: 5px;font-size: 20px;border: solid;border-color: #f0f0f0;margin-top: -20px;">DEBIT NOTE</h3>
							<?php //} else if($row_supplier['billing_type']=='4'){ ?>
							<h3 style="text-align: center;padding: 5px;font-size: 20px;border: solid;border-color: #f0f0f0;margin-top: -20px;">CREDIT NOTE</h3>
							<?php //} else if($row_supplier['billing_type']=='5'){ ?>
							<h3 style="text-align: center;padding: 5px;font-size: 20px;border: solid;border-color: #f0f0f0;margin-top: -20px;">PURCHASE INVOICE</h3>
							<?php //} ?>
							
                            <div class="col-md-12" style="border: solid;border-color: #f0f0f0;margin-top: -11px;">
					 
                    <div class="row">
                        <div class="col-md-6" style="border-right: solid;border-color: #f0f0f0">
							<p><b>Service Provider :</b><br>
							<?php                           
							  //$sql = "SELECT * FROM tbl_admin WHERE  admin_id='1'";
							  //$resul = $conn->query($sql);  
							  //$row = $resul->fetch_assoc();
							 ?>
								<b><?php //echo $row['cname']; ?></b>,<br>
								<?php //echo nl2br ($row['addr']);?><br>
								<b>GST No :</b> <?php //echo $row['gstno']; ?>
							</p><hr>
                            <p><b>Consin :</b><br>
								<?php //if(!empty($supplier_company)){ ?>
								<?php //echo $supplier_company; ?><br>
								<?php //} ?>                                                
								<?php //if(!empty($supplier_address)){ ?>
								<?php //echo $supplier_address; ?>
								<?php //} ?><br>
								<?php //if(!empty($supplier_gst_no)){ ?> 
								GST No : <?php //echo $supplier_gst_no ?>
								<?php //} ?>
							</p>
						</div>
                        <div class="col-md-6">
							<p><b>Invoice No. & Date </b>: <?php //echo $billing_no ?> & <?php //echo $billing_date ?><br>
								Buyer's Order No. : <?php //echo nl2br ($row_supplier['order_detail']); ?> <br>
							</p>
						</div>
					</div>
					</div-->


                    <div class="row" style="margin-top: 50px;">
                            

                            <div class="col-sm-12">

                                <div>

                                <p style="text-align: left; padding: 5px; border-top: solid;border-right: solid;border-left: solid;border-color: #f0f0f0;margin-top: 10px;"><br>
                                        <img src="images/logo.png" width="100" alt="">
                                        <?php                           
                                        $sql = "SELECT * FROM tbl_admin WHERE  admin_id='1'";
                                        $resul = $conn->query($sql);  
                                        $row = $resul->fetch_assoc();
                                        ?>
                                            <span style="text-align: left; font-size: 30px; text-width:bold;"><?php //echo $row['cname']; ?></span><br><br>
                                            
                                            <span style="float:right; text-align: right; padding: 10px;font-size: 14px; margin-top: -150px;">                              
                                                        

                                            <span style="font-size: 30px;">INVOICE</span>
                                
                                           

                                            <br><?php echo nl2br ($row['addr']);?><br>
                                            <b>GST No :</b> <?php echo $row['gstno']; ?></span>

                                </p>

                            </div>
                            
							
                                <div class="col-md-12" style="border: solid;border-color: #f0f0f0;margin-top: -11px;">
                        
                                    <div class="row">
                                        <div class="col-md-6" style="border-right: solid;border-color: #f0f0f0">                                            
                                            
                                            <p><b>Service Provider :</b><br>
                                            <?php                           
                                            $sql = "SELECT * FROM tbl_admin WHERE  admin_id='1'";
                                            $resul = $conn->query($sql);  
                                            $row = $resul->fetch_assoc();
                                            ?>
                                                <b><?php echo $row['cname']; ?></b>,<br>
                                                <?php echo nl2br ($row['addr']);?><br>
                                                <b>GST No :</b> <?php echo $row['gstno']; ?>
                                            </p><hr>
                                            <p><b>Supplier :</b><br>
                                                <?php if(!empty($supplier_name)){ ?>
                                                <?php echo $supplier_name; ?><br>
                                                <?php } ?>
                                                <?php if(!empty($supplier_company)){ ?>
                                                <?php echo $supplier_company; ?><br>
                                                <?php } ?>                                                
                                                <?php if(!empty($supplier_address)){ ?>
                                                <?php echo $supplier_address; ?>
                                                <?php } ?><br>
                                                <?php if(!empty($supplier_gst_no)){ ?> 
                                                GST No : <?php echo $supplier_gst_no ?>
                                                <?php } ?>
                                            </p>
                                        </div>
                                        <div class="col-md-6">                                            

                                            <p><b>Invoice No</b>: <?php echo $billing_no ?> <br>
                                            <b>Date </b>: <?php echo $billing_date ?><br>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <table  class="table table-striped table-bordered" width="100%"  style="border: none;">
                                    <thead>
                                        <tr>
                                            <th style="width: 10%">Sl.no</th>	
                                            <th style="width: 25%">Product</th>									
                                            <th style="width: 15%">HSN Code</th>
                                            <th style="width: 10%">UOM</th>
                                            <th style="width: 10%">Quantity</th>
                                            <th style="width: 20%">Rate</th>
                                            <th style="width: 15%">Amount</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        <?php

                                            $sql = "SELECT b.*,a.total_amount,a.gst_total_amount,e.uom_name,a.grand_total_amount FROM tbl_stock  a 
                                            inner join tbl_stock_details b on a.stock_id=b.stock_id 
                                            left join  tbl_uom e on e.uom_id=b.uom_id 
                                            left join  tbl_supplier d on d.supplier_id=a.supplier_id WHERE  a.delete_status!='0' and  b.delete_status!='0' and    d.delete_status!='0' and b.stock_id='".$_GET['id']."'";
                                            $query = mysqli_query($conn, $sql);
                                            
                                            $j=0;
                                            $total_amount=0;
                                        while ($fetch_booking_details = mysqli_fetch_array($query)) {
                                            
                                            $total_amount=$total_amount+$fetch_booking_details['rate'];  
                                            
                                            $gql3 = "SELECT b.category_name,c.sub_category_name,a.design FROM tbl_products a left join  tbl_category b on b.category_id=a.category_id left join  tbl_sub_category c on c.sub_category_id=a.sub_category_id left join  tbl_stock_details d on d.product_id=a.product_id where a.delete_status='NDL' and a.product_id='".$fetch_booking_details['product_id']."' ";
											$exec_gql3 = mysqli_query($conn, $gql3);			
											$fetch_gql3 = mysqli_fetch_array($exec_gql3);

                                            
                                        ?>


                                            <tr style="page-break-inside: avoid">
                                                <td class="text-center"><?php echo $j + 1; ?></td>
                                                <td class="text-center"><?php echo $fetch_gql3["category_name"]."-".$fetch_gql3["sub_category_name"]."-".$fetch_gql3["design"]; ?></td>
                                                
                                                <td class="text-center"><?php echo $fetch_booking_details['hsn_code']; ?></td>
                                                <td class="text-center"><?php echo $fetch_booking_details['uom_name']; ?></td>
                                                <td class="text-center"><?php echo $fetch_booking_details['qty']; ?></td>
                                                <td class="text-center" style="width: 15%; text-align: right;"><?php echo number_format((float) $fetch_booking_details['product_rate'], 2, '.', ''); ?></td>
                                                <td class="text-center" style="width: 15%; text-align: right;"><?php echo number_format((float)$fetch_booking_details['rate'], 2, '.', ''); ?></td>
                                                
                                            </tr>

                                        <?php

                                            $j++;

                                            
                                        } ?>

                                        <?php

                                        //$i = $ten - $count;
                                       // for ($z = $count; $z < $ten; $z++) { ?>

                                            <tr style="page-break-inside: avoid">
                                                <td><?php //echo $j+1; ?></td>
                                                <!-- <td></td> -->
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
												<td></td>
                                                <td></td>
                                                
                                            </tr>


                                        <?php //} ?>

											<tr class="taxdiv" id="taxdiv0" style="page-break-inside: avoid">                                              

												<th colspan="5" class="text-right" style="padding:2px">Total </th>
												<th colspan="2" class="text-right" style="padding:2px"><?php echo number_format((float)$total_amount, 2, '.', ''); ?></th>
											</tr>

                                            <?php
                                            
                                            function convertToIndianCurrency($number) {
                                                $no = round($number);
                                                $decimal = round($number - ($no = floor($number)), 2) * 100;    
                                                $digits_length = strlen($no);    
                                                $i = 0;
                                                $str = array();
                                                $words = array(
                                                    0 => '',
                                                    1 => 'One',
                                                    2 => 'Two',
                                                    3 => 'Three',
                                                    4 => 'Four',
                                                    5 => 'Five',
                                                    6 => 'Six',
                                                    7 => 'Seven',
                                                    8 => 'Eight',
                                                    9 => 'Nine',
                                                    10 => 'Ten',
                                                    11 => 'Eleven',
                                                    12 => 'Twelve',
                                                    13 => 'Thirteen',
                                                    14 => 'Fourteen',
                                                    15 => 'Fifteen',
                                                    16 => 'Sixteen',
                                                    17 => 'Seventeen',
                                                    18 => 'Eighteen',
                                                    19 => 'Nineteen',
                                                    20 => 'Twenty',
                                                    30 => 'Thirty',
                                                    40 => 'Forty',
                                                    50 => 'Fifty',
                                                    60 => 'Sixty',
                                                    70 => 'Seventy',
                                                    80 => 'Eighty',
                                                    90 => 'Ninety');
                                                $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
                                                while ($i < $digits_length) {
                                                    $divider = ($i == 2) ? 10 : 100;
                                                    $number = floor($no % $divider);
                                                    $no = floor($no / $divider);
                                                    $i += $divider == 10 ? 1 : 2;
                                                    if ($number) {
                                                        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;            
                                                        $str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural;
                                                    } else {
                                                        $str [] = null;
                                                    }  
                                                }
                                                
                                                $Rupees = implode(' ', array_reverse($str));
                                                $paise = ($decimal) ? "And Paise " . ($words[$decimal - $decimal%10]) ." " .($words[$decimal%10])  : '';
                                                return ($Rupees ? 'Rupees ' . $Rupees : '') . $paise . " Only";
                                            }
                                                ?>

                                        <?php  
                                            $cgst_amount=number_format((float)$total_amount * ($row_supplier['cgst'] / 100), 2, '.', '');
                                            $sgst_amount=number_format((float)$total_amount * ($row_supplier['sgst'] / 100), 2, '.', '');
                                            $total_amount1=number_format((float)$total_amount, 2, '.', '');
                                            $total_amount_word=$total_amount1+$cgst_amount+$sgst_amount
                                            
                                        ?>

                                            
											<tr class="taxdiv" id="taxdiv0" style="page-break-inside: avoid">
                                                <th colspan="4">Amount in words: </th>
												<th  class="text-center" style="padding:2px">CGST</th>
												<th  class="text-right" style="padding:2px"><?php echo $cgst; ?>%</th>
                                                <th  class="text-right" style="padding:2px; text-align: right;"><?php echo $cgst_amount=number_format((float)$total_amount * ($row_supplier['cgst'] / 100), 2, '.', '');?></th>

											</tr>
                                            
											<tr class="taxdiv" id="taxdiv0" style="page-break-inside: avoid">
                                                <td colspan="4"><b>Rupees :</b> <?php  echo convertToIndianCurrency($total_amount_word);?></td>

												<td  class="text-center" style="padding:2px">SGST</td>
												<td  class="text-right" style="padding:2px"><?php echo $sgst; ?>%</td>
                                                <td  class="text-right" style="padding:2px; text-align: right;"><?php echo $sgst_amount=number_format((float)$total_amount * ($row_supplier['sgst'] / 100), 2, '.', '');?></td>

											</tr>
                                            <tr style="page-break-inside: avoid">
											<?php                           
											  $sql = "SELECT * FROM tbl_admin WHERE  admin_id='1'";
											  $resul = $conn->query($sql);  
											  $row = $resul->fetch_assoc();
											 ?>
                                                <td colspan="4" style="width: 50%"><b>Bank :</b> <?php echo $row['bank']; ?><br>
                                                <b>Branch :</b> <?php echo $row['branch']; ?><br>
                                                <b>A/C No :</b> <?php echo $row['acc_no']; ?><br>
                                                <b>Account Type :</b> <?php echo $row['acc_type']; ?><br>
                                                <b>IFSC  :</b> <?php echo $row['ifsc']; ?><br>
                                                <b>A/C Name  :</b> <?php echo $row['holder_name']; ?>
                                                    
                                                
                                                </td>
                                                
                                                <th ></th>
                                                <th  style="text-align:right"><br><br><br><br><br>Grand Total</th>
                                                <th  style="text-align:right"><br><br><br><br><br><?php echo number_format((float)$total_amount+$cgst_amount+$sgst_amount, 2, '.', ''); ?></th>
                                                    
                                                </th>

                                        </tr>
																	
											
											
                                    </tbody>
                                    <tfoot >
										
										<tr style="page-break-inside: avoid">
										
											<td colspan="4" class="text-right">
											</td>
											
											<td colspan="4" style="text-align: center">
											<p style="margin-bottom: 0rem;font-size:15px"><b>FOR TAMILCARDS</b></p>
												<img src="images/no_image.png" style="width:130px;height:109px;text-align:center;object-fit:contain">
											<p style="text-align:center;font-size:15px">Authorizes Signatory</p>
											</td>
											
										</tr>
										
                                        
                                    </tfoot>						
									
									
                                </table>
                            </div>

                        </div>



                    </div>
                </div>
            </div>
        </div>
    </main>




    <!-- end::main content -->
    <style>
        .dataTables_length {
            text-align: left;
        }

        .dataTables_filter {
            text-align: left;
        }
    </style>
    <!-- begin::global scripts -->
    <?php include("footer.php") ?>



<!-- begin::global scripts -->

<!-- end::global scripts -->
<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="js/examples/datatable.js"></script>
<!-- begin::charts -->
<script src="vendors/charts/chartjs/chart.min.js"></script>
<script src="vendors/charts/peity/jquery.peity.min.js"></script>
<script src="js/examples/charts/chartjs.js"></script>
<script src="js/examples/charts/peity.js"></script>
<!-- end::charts -->
<!-- START::select2 -->
<script src="vendors/select2/js/select2.min.js"></script>
<script src="js/examples/select2.js"></script>
<!-- end::select2 -->
<!-- begin::daterangepicker -->
<script src="vendors/datepicker/daterangepicker.js"></script>
<!-- end::daterangepicker -->

<!-- begin::dashboard -->
<script src="js/examples/dashboard.js"></script>
<!-- end::dashboard -->

<!-- begin::vamp -->
<script src="vendors/vmap/jquery.vmap.min.js"></script>
<script src="vendors/vmap/maps/jquery.vmap.usa.js"></script>
<script src="js/examples/vmap.js"></script>
<!-- end::vamp -->

<!-- begin::custom scripts -->
<script src="js/custom.js"></script>
<script src="js/app.min.js"></script>
<!-- end::custom scripts -->

</body>
<style>
    .card .card-body,
    .page-header .card-body {
        padding: 17px;
        padding-bottom: 0px;
    }

    @media print {
        .bottomdiv {
            display: none !important;
        }

        body {
            padding: 0;
        }
    }

    @media(min-width:992px) {
        .navbar-nav {
            display: block !important;
            width: 100%;
        }

        .userdiv {
            float: right;
        }

        .mybut {
            margin-top: 33px;
        }
    }

    @media(max-width:480px) {
        nav.navbar .header-logo a img {
            width: 180px;
        }
    }

    .table td {
        vertical-align: bottom !important;
        padding: 5px;
    }
</style>


<script>

</script>

</html>