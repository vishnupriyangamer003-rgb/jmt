<?php if (session_status() !== PHP_SESSION_ACTIVE) session_start(); ?>
<?php
header('Access-Control-Allow-Origin: *');
	//include connection file 
	include_once("sessionservices.php");
	// include_once("header.php");

// storing  request (ie, get/post) global array to a variable
$requestData= $_REQUEST;
$draw = intval($requestData['draw'] ?? 0);
$start = intval($requestData['start'] ?? 0);
$length = intval($requestData['length'] ?? 10);
if ($length <= 0) $length = 10;

$columns = array( 
// datatable column index  => database column name
	0 =>'title', 
	
		
	
);

// getting total number records without any search
$sql = "SELECT customer_id FROM tbl_customer WHERE delete_status!='0'";
$query=mysqli_query($conn, $sql) or die("tbl_prpty-grPrpty_Id-data.php: get tbl_prptys");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT customer_id,customer_name,reference_name,company_name,mblno,owner_contact,address,date_format(create_date,'%d/%m/%Y %r') as create_date,date_format(update_date,'%d/%m/%Y %r') as update_date,created_by,updated_by FROM tbl_customer where delete_status!='0' ";



// print_r($sql);
if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
	$search = mysqli_real_escape_string($conn, $requestData['search']['value']);
	$sql.=" AND (( customer_name LIKE '%".$search."%') 
	OR ( reference_name LIKE '%".$search."%')
	OR ( company_name LIKE '%".$search."%')
	OR ( mblno LIKE '%".$search."%'))";   
	
}
$query=mysqli_query($conn, $sql) or die("tbl_prpty-grPrpty_Id-data.php: get	 tbl_prptys");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result.
$sql.=" order by customer_name  ASC  LIMIT ".$start." ,".$length."   ";

/* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
$query=mysqli_query($conn, $sql) or die("tbl_prpty-grPrpty_Id-data.php: get tbl_prptys");

$data = array();
$i=1+$start;
while( $row=mysqli_fetch_array($query) ) {  // preparing an array
	$nestedData=array(); 

	$nestedData[] = "#".$i ;
	if($row['customer_name']==''){
		$nestedData[] = "-";
	}
	else{
		$nestedData[] = str_replace("^","'",$row["customer_name"]);
	}

	if(empty($row['reference_name'])){
		$nestedData[] = "-";
	}
	else{
		$nestedData[] = str_replace("^","'",$row["reference_name"]);
	}

	if($row['company_name']==''){
		$nestedData[] = "-";
	}
	else{
		$nestedData[] = str_replace("^","'",$row["company_name"]);
	}
	
	if($row['mblno']==''){
		$nestedData[] = "-";
	}
	else{
		$nestedData[] = str_replace("^","'",$row["mblno"]);
	}
	if(empty($row['owner_contact'])){
		$nestedData[] = "-";
	}
	else{
		$nestedData[] = str_replace("^","'",$row["owner_contact"]);
	}
	if($row['address']==''){
		$nestedData[] = "-";
	}
	else{
		$nestedData[] = str_replace("^","'",$row["address"]);
	}
	// $nestedData[] = "<img src='userdata/images/banner/".str_replace("^","'",$row["imgname"])."' style='width:100px'>";
	if($row['update_date']!=''){
		if($row['updated_by']=='admin' || $row['updated_by']=='Admin' || $row['updated_by']=='1'){
			$nestedData[]='<span class="badge badge-info">Updated by Admin  on '.$row['update_date'].'</span>';
		}
		else{
			$gql="select emp_name from tbl_employee_details where delete_status!='0' and emp_code='".$row['updated_by']."'";
			$exec_gql=mysqli_query($conn,$gql);
			$fetch_gql=mysqli_fetch_array($exec_gql);
			$nestedData[]='<span class="badge badge-info">Updated by '.$fetch_gql['emp_name'].' on '.$row['create_date'].'</span>';
		}
	}
	else{
		// echo ($row['created_by']);
		if($row['created_by']=='admin' || $row['created_by']=='Admin' || $row['created_by']=='1'){
			$nestedData[]='<span class="badge badge-success">Created by Admin on '.$row['create_date'].'</span>';
		}
		else{
			$gql="select emp_name from tbl_employee_details where delete_status!='0' and emp_code='".$row['created_by']."'";
			$exec_gql=mysqli_query($conn,$gql);
			$fetch_gql=mysqli_fetch_array($exec_gql);
			$nestedData[]='<span class="badge badge-success">Created by '.$fetch_gql['emp_name'].' on '.$row['create_date'].' </span>';
		}
	}

    $nestedData[] ="<div class='btn-group' role='group' aria-label='Basic example'>
																	<a href='customer_update.php?id=".$row['customer_id']."'><button type='button' class='btn btn-success' style='padding:6px 8px;margin-right:5px'>
																		<i class='fa fa-edit' style='color: #fff;padding: 0;margin: 0;font-size: 18px;'></i>
																	</button></a>
																	<a href='javascript:void(0)' class='deleteTriger' data-value='".$row['customer_id']."'><button type='button' class='btn btn-danger' style='padding:6px 8px;'>
																		<i class='fa fa-trash' style='color: #fff;padding: 0;margin: 0;font-size: 18px;'></i>
																	</button></a>
																</div>";
	
	
	$data[] = $nestedData;
	$i++;
}



$json_data = array(
			"draw"            => $draw,   // for every request/draw by clientsPrpty_Ide , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw.
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format


?>
	